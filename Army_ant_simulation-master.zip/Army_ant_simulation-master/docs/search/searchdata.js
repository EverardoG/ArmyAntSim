var indexSectionsWithContent =
{
  0: "abcdefghilmnrstvw",
  1: "bcdmrstv",
  2: "cdmrtv",
  3: "abcdfghilmnrstw",
  4: "mr",
  5: "es",
  6: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Pages"
};

