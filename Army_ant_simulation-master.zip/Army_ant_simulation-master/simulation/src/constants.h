/*
 * constants.h
 *
 *  Created on: 28 sept. 2018
 *      Author: lucie
 */

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

#define PI 3.14159265358979323846
#define RAD_TO_DEG (180/PI)
#define FPS 60.f

#endif /* CONSTANTS_H_ */
