# Experiments Folder

This empty folder is wthe default location for the result files created everytime the simulation is run.
